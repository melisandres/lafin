<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1" name="viewport">
<link href="main.css" rel="stylesheet">
<link href="script.js" rel="script">
<link href="information.php" rel="script">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!--- Favicon -->
<link rel="icon" href="/favicon_io/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon_io/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon_io/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon_io/favicon-16x16.png">
<!--- End Favicon -->

<!--- there are some functions I want to re-execute on each page load -->
<!--- AND a few functions I want to have access to from everywhere -->