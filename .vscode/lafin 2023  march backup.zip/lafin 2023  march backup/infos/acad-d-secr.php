<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Our academics are currently working behind closed doors. This is could mean that they're up to no good.</p>
	<p>Check the time-line for past and/or future publications.</p>
	</div>

	<button type="button" class="collapsible">classes</button>
	<div class="content">
		<p>Student-lead seminars have been sprouting up in unlikely places. These, we've been told, are digging in obscure and unconventional directions.</p>
	</div>	

	<button type="button" class="collapsible">faculty</button>
	<div class="content">
		<p>Our past and current faculty are revising aspects of the curriculum, in response to our new priorities.</p>
	</div>

	<button type="button" class="collapsible">students</button>
	<div class="content">
		<p>Our graduate students are transforming the education wing. Our goal is to adapt quickly, and responsively.</p>  		
	</div>
</div>


