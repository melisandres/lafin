<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Winter Session, come back later... we aren't ready for the snow.</p>
	</div>

	<button type="button" class="collapsible">statement</button>
	<div class="content">
		<h4>we foresaw a pandemic</h4>
		<p>Well, not exactly... but we did start social distancing before it was cool</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>notes found on the deserted academy premises:</h4>
		<p>"I's sorry, can I take a raincheck for tonight. With this weather, I'll be suprised if I make it home."</p>
		<p>"All her clothes are made from recycled blankets. All his teeth were made from bits of kindling."
		<p>"There's a care package for you downstairs. I think it's alive."</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<p>We don't believe in doing things we don't want to do, unless absolutely necessary.</p>
	</div>

</div>


