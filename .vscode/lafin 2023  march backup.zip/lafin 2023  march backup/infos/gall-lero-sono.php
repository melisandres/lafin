<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>The art of M. Leon Leroux. Pioneer in the Upwards and Downwards Movements, Mr Leroux has spent the last 10 years creating SOnoRizaTIon, a persistent montage of daily vocalizations on a white background of milk and fish.</p>
	</div>

	<button type="button" class="collapsible">statement</button>
	<div class="content">
		<h4>Mee-oow</h4>
		<p>Don't say art is just for the humans! Although, technically, this text is an anthromorphisization of me! oW! Humans are anthropomorphic--but they aren't the only ones. As if ignorance of the other makes the other cease to exist meaningfully within themselves. Whole lotta bullshit. I'm an artist. I have a voice. Even if the "I" here should be loosely interpreted, as the voice of a human pretending to write for me.</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>recovered notes:</h4>
		<p>purrrr</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<h4>swish swish swish</h4>
		<p>Mrowr</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>M. Leon Leroux</h4>
			<p>Je suis née un endroit indéterminé, on me dit, près de la ville de Montréal.</p>  		
	</div>
</div>


