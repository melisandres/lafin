<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>"The Board was able to get away for longer
	that year. The cottage had bed-sized rooms lining
	an open space. Beauregard found the spot, his
	cousin built it in the eighties. The dirt driveway 
	was shared with an old dock used by a few locals on 
	weekends. It was off the highway. I somehow remember 
	the highway most clearly."</p>
	<p>"There were dogs. The cousin's dogs were massive. 
	Afghan hounds. And there was little Bonefry, Beauregard's 
	dog. More of a city dog. I think that's why the 
	highway took up so much space. That, and... I mean, it 
	wasn't much of a highway, a secondary road at best. It 
	would get transport trucks, and then nothing, for hours."
	</p>
	<p>-V. Knee</p>
	</div>

	<button type="button" class="collapsible">archivist statement</button>
	<div class="content">
		<h4>A stretch of highway</h4>
		<h5>somewhere between Moncton and Edmundston, in New Brunswick .</h5>
		<p>We caught something under the words, a wistfulness
		about an indifferent stretch of highway. Vague memories:
		a quasi-accident, a family of bears, a trip to the gas 
		station for eggs, dogs happy to be dogs, the closest neighhours
		are trees, and so many trees. </p>
	</div>	

</div>
