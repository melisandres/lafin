<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>The presses are running? Or are they hiding? They are not sharing, not at the moment. This is possibly because they are up to no good.</p>
	<p>Check the time-line for past and/or future publications.</p>
	</div>

	<button type="button" class="collapsible">more info...</button>
	<div class="content">
		<h4>information about how we fill our time</h4>
		<p>No more information is available at this time. We're probably reading through the mountainous fictional slush pile.</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>recovered notes:</h4>
		<p>No notes recovered at this time</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<h4>other</h4>
		<p>no other, or more, or different bits of information are available for us to share. The secret recesses of our printing press are just that, unfathomable.</p>
	</div>

	<button type="button" class="collapsible">bios</button>
	<div class="content">
		<h4>our editors editors</h4>
		<p>Our illustrious editors are not sharing any information about themselves at the present time.</p>  		
	</div>
</div>


