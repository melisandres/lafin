<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Inside the clamber bondyo shinset boo of the pommel pommel blintz, there are five additional  quinzen, but I heard, because, well... I was listening, that four of them--possibly the most intriguing ones, have gone missing. I wouldn't be surprised. There are a few things that I suspect. I've been watching, across the vivinfaire, when the colours turn to dirty minsboo, like soaked crimson. On nights like last night, when I've seen the moving shadows swallow everything.</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<h4>other</h4>
		<p>clim clam, buddah buddah, chip chip chip, beeeee.</p>
	</div>	

	<button type="button" class="collapsible">HUSH</button>
	<div class="content">
		<h4>Seriously: don't breathe a syllable!</h4>
		<p>there are things that shouldn't be things, or acknowledged to be things.<br><br><br><br>even if you really want to say<br><br><br><br>...even if you really really want to know.</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>Candace Flint</h4>
			<p>Ms Flint is the third of nine children, graduated ninth of her class of twenty-nine, and came in twenty-ninth in the county marathon in 1998. She writes novels that are not read, and reads silently, under her breathe. <em>Under your Hat</em> is the result of years worth of keeping all the things to herself.</p>  		
	</div>
</div>


