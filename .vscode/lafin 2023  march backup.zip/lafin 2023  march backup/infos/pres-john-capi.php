
<div class="archive-c-text">
<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Every relationship has its own special economy, defined by its unique brand of transactionality. That's why, the protagonist that journeys through a story built from a capitalist framework is also isolated by it, ensconced in predictable relationships, plastic drama, and the tyrany of an economic system that smothers other systems into submission. When economics and poetry can no longer share the stage, the individual is left with the box office hit, five times in a row, blockbuster6, a yawn fest that the protagonist can only engage in as a fraction of himself, the part of himself too tired to vacate... he becomes loneliness incarnate watching the story forever told, because it's the story that made the most money the last time around, and the time before that, the product of a circular narrative/economical darwinian hellscape.</p>
	</div>
</div>
