<div class="archive-c-text">	

	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Reading with eyes closed. Stacey Ruggenbaum has taken on the task of launching a new Press project: 'Whispered audiobooks.' There are moments where only a whisper will do.</p>
	</div>

	<button type="button" class="collapsible">the collection</button>
	<div class="content">
		<h4>the collection</h4>
		<p>a baby's breath, and we brought together, arrangement, wonderful... scrumptious, enmeshed... with multifaceted... but silent. SENSORY. The world is SENSORY. And all the words, all the whispers coalesce.</p>
	</div>	

	<button type="button" class="collapsible">samples</button>
	<div class="content">
		<h4>samples</h4>
		<p>"...", "...", "..."........."</p>
	</div>

	<button type="button" class="collapsible">thanks</button>
	<div class="content">
		<h4>special thanks to:</h4>
		<p>more information, and people can be found here. A super, never-ending...</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>Stacey Ruggenbaum, editor</h4>
		<p>text here... text here... text here...</p>  		
	</div>
</div>


