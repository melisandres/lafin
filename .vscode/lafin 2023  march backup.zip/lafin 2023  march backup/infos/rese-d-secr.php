<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Secret research is not always bad...</p>
	</div>

	<button type="button" class="collapsible">statement</button>
	<div class="content">
		<h4>NONE</h4>
		<p>We have no official statement regarding Secret Research. If such a thing existed, we couldn't possibly be expected to comment.</p>
	</div>	

	<button type="button" class="collapsible">portal</button>
	<div class="content">
		<h4>classified portal </h4>
		<p>if authorized, please enter your password:<br>
 		<label for="pwd">Password:</label>
		<input type="password" id="sec_rese-pwd" name="sec_rese-pwd"> </p>
	</div>

	<button type="button" class="collapsible">HUSH</button>
	<div class="content">
		<h4>we don't look kindly on</h4>
		<p>people going about and blabbing about our private business.</p>
	</div>

	<button type="button" class="collapsible">bios</button>
	<div class="content">
		<h4>secret researchers</h4>
		<p>The ethics codes here are a little topsy-turvy. Our foremost privacy concerns are for the participants, if they exist. And also if they don't quite exist--the line is not always clear.</p>  		
	</div>
</div>


