<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Do you dream of flying? Our current research project exists in the form of a survey.</p>
	</div>

	<button type="button" class="collapsible">statement</button>
	<div class="content">
		<h4>statement of intent</h4>
		<p>I've always felt flying dreams were particularly meaningful, but... who knows?</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>notes:</h4>
		<p>subject 98: I dream about flying rarely. I think the last time I did, I must have been a teenager, or maybe in university. I think flying dreams are for young people. People who feel invincible.<br>subject 13: I've never had a dream. No one in my family dreams. I used to think that people made up the whole concept. I still don't totally believe it isn't some kind of conspiracy, to make me look like a fool for believing anything.<br>subject 76: I have falling dreams where I hope to god I'll be able to fly before I hit the ground. I'm never able to fly, but I also never quite hit the ground. I wake up in a sweat, but not to this reality... to the reality of another dream</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<h4>What would you like?</h4>
		<p>other description.</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>Melisandre Schofield</h4>
			<p>Mé is not a fictional person, but she sure like to hang out with them. If she had it her way, the whole world might be fiction, and then who'd be left? No, no, no. Mé is pragmatic. She likes real people too. They make the best fictional people. Really.</p>  		
	</div>
</div>


