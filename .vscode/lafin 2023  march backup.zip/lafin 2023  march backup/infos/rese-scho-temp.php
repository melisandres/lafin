<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>about</p>
	</div>

	<button type="button" class="collapsible">statement</button>
	<div class="content">
		<h4>statement title</h4>
		<p>statement description.</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>recovered notes:</h4>
		<p>Notes description</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<h4>other title</h4>
		<p>other description.</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>Name</h4>
		<p>bio</p>  		
	</div>
</div>