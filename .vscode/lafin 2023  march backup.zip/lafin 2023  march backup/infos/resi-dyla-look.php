<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>While reading the then newly published classic <i>The Lion the Witch and the Wardrobe</i>, both Bobby and his son became hauted by persistant thought of Turkish Delight, the sweet so delicious that it could turn a boy against his family, and help plunge the world into never-ending winter.</p>
    <p>For Bobby, this obsession marked the beginning of an extended candy-making period that lasted the length of the residency and beyond.</p>
	</div>

	<button type="button" class="collapsible">host statement</button>
	<div class="content">
		<h4>recovered notes:</h4>
		<p>Salty lokum, marshmallows, and wine gums. We might have wished for culinary research that obsessed over fish, but we satisfied ourselves with swedish fish.</p>
	</div>
</div>