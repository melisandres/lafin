<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
		<p>The middle room residency ran from 2003 to 2005, with a short hiatus in 2005 while resident Vincent Applebee used his residency as an opportunity to host a residency of his own&mdash;in the closet. After Vincent and closet-resident Jeremy finished their work and returned home, the middle room residency continued only for a few short months, as Mélisandre packed her belongings and prepared for a move to Toronto. </p>
	</div>

	<button type="button" class="collapsible">host statement</button>
	<div class="content">
		<i><p>Vaughn's residency was barely a week after Jeremy and Vincent left. And once the appartment was empty, it felt incredibly hollow, and cavernous, and cold. I was writing a novel at the time, and there was an empty space in the very centre of my novel. It felt like circumstances were conspiring to teach me something meaningful, about emptiness.</p></i>
		<p>-Mélisandre Schofield</p>
	</div>	
</div>


