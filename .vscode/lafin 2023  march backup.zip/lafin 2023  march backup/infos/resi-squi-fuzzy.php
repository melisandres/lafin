<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Currently residing in a make-shift terrarium, our resident is, for this week only, Sir Squishy, a shinny caterpillar.</p>
	</div>

	<button type="button" class="collapsible">host statement</button>
	<div class="content">
		<h4>----</h4>
		<p>A trail of slime glimmers before it becomes invisible. But this is a caterpillar, not a slug... wait, is it a slug?</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>recovered notes:</h4>
		<p>find out the difference between caterpillars and slugs.</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>Sir Squishy</h4>
		<p>A caterpillar, a moth, but such a short life. God bless him.</p>  
		<p>(Probably a slug.)</p>		
	</div>
</div>


