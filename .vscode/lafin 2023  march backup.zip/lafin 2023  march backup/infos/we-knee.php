<div class="archive-c-text">	
	<button type="button" class="collapsible">about</button>
	<div class="content">
	<p>Based in Brooklyn, Vaughn is director of Lafin's Education Wing. Known internationally for his large scale paper sculptures, Vaughn's work combines sculpture, theatre, costume/set design, and narrative investigations.Vaughn Knee is working with Lafin in the development of its curriculum.</p>
	</div>

	<button type="button" class="collapsible">statement</button>
	<div class="content">
		<h4>statement title</h4>
		<p>statement description.</p>
	</div>	

	<button type="button" class="collapsible">notes</button>
	<div class="content">
		<h4>recovered notes:</h4>
		<p>Notes description</p>
	</div>

	<button type="button" class="collapsible">other</button>
	<div class="content">
		<h4>other title</h4>
		<p>other description.</p>
	</div>

	<button type="button" class="collapsible">bio</button>
	<div class="content">
		<h4>Name</h4>
		<p>bio</p>  		
	</div>
</div>