#LAFIN
The Liberal Arts Fictional Institute of Narrative is a loose collective of artists, writers, and intellectuals who are, for the most part, fictional. We investigate narrative through narrative, and fiction through fiction, the lenses blurr, the images distort, revealing other truthes.# lafin
